package com.example.toonflix

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
